from setuptools import setup

package_name = 'robot_urdf'

setup(
    name=package_name,
    version='0.0.0',
    packages=[package_name],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='carmine',
    maintainer_email='carmine@todo.todo',
    description='Robot URDF package',
    license='TODO',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'robot_mover = robot_urdf.robot_mover:main',
        ],
    },
)

